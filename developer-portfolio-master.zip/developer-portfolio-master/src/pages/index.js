export { default as BlogPage } from './blog/index'
export { default as HomePage } from './home/index'
export { default as ProjectPage } from './project/index'

