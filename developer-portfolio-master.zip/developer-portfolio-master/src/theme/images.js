import contactsImage from '../assets/svg/contactsImage.svg';


export {
    contactsImage
};

