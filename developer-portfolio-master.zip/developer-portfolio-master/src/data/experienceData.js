export const experienceData = [
    {
        id: 1,
        company: 'Teton Private Limited',
        jobtitle: 'Software Engineer I',
        startYear: 'Jan 2022',
        endYear: 'Present'
    },
    {
        id: 2,
        company: 'Fiverr(freelance)',
        jobtitle: 'Full-Stack Developer',
        startYear: 'Jun 2021',
        endYear: 'Jan 2022'
    },
    {
        id: 3,
        company: 'Learning New Technology For Everyday',
        jobtitle: 'Self Learning',
        startYear: '2018',
        endYear: 'Present'
    },
]