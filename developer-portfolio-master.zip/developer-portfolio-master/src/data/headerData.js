
export const headerData = {
    name: 'ABU SAID',
    title: "Hello! I am",
    desciption: "Hello! I am ABU SAID, a professional and passionate programmer in my daily life. A quick learner with a self-learning attitude. I love to learn and explore new technologies and am Passionate about Problem Solving. ",
    image: 'https://i.ibb.co/ZmdNH6x/abu-said.jpg',
    imagebw: 'https://i.ibb.co/Cw2Xp90/abu-said-bw.jpg',
    resumePdf: 'https://docs.google.com/document/d/1MkkoRX98FS47CaEyeodyPzi4OkW8SH7Gv55f4MQkHV8/edit?usp=sharing'
}
